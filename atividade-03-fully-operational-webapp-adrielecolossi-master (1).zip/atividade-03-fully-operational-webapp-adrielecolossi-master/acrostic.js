/* eslint-disable max-len */
/* eslint-disable max-statements */
/* eslint-disable prefer-const */
console.info('acrostic.js');
let umavez = 0;
let wordslist = '';
let min;
document.querySelector('h1').addEventListener('click', function(e) {
    e.target.textContent += '!';
});
let z = 0;
const acrostic = {
    add: function addWords(e) {
        const text = document.querySelector('textarea').value;
        let textt = '';
        for (let i = 0; i < text.length; i++) {
            if (text[i] === ' ') {
                textt += '';
            } else {
                textt += text[i];
            }
        }
        wordslist = textt.split(',');
        const alp = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
            'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T',
            'U', 'V', 'W', 'X', 'Y', 'Z'];
        let error = false;
        for (let x = 0; x < wordslist.length; x++) {
            wordslist[x] = wordslist[x].toUpperCase();
            if (wordslist.indexOf(wordslist[x]) !== x) {
                error = true;
                throw new Error('Há palavras repetidas');
            }
            for (let c = 0; c < wordslist[x].length; c++) {
                if (alp.indexOf((wordslist[x]).charAt(c)) === -1 &&
                    error === false) {
                    error = true;
                    console.log('Um dos caracteres não está no afalbeto');
                }
            }
        }
        if (error === false) {
            document.body.children[3].textContent += wordslist;
        }
    },
    remove: function removeWords(e) {
        document.body.children[3].textContent = '';
        if (wordslist !== '') {
            wordslist = '';
        }
    },
    tirar: function tirar(vetor, palavraquequerretirar) {
        let resposta = [];
        vetor = (vetor.join());
        let x = palavraquequerretirar;
        vetor = vetor.substr(0, (vetor.indexOf(x) - 1)) + vetor.substr((vetor.indexOf(x) + x.length));
        vetor = vetor.split(',');
        for (let p = 0; p < vetor.length; p++) {
            if (vetor[p] !== '') {
                resposta.push(vetor[p]);
            }
        }
        return resposta;
    },
    wordslist: wordslist,
    generate: function generate(e) {
        let pword = (document.querySelector('input').value);
        pword = pword.toUpperCase().trim();
        z = pword.length;
        if (z !== 0) {
            for (let q = 0; q < z; q++) {
                document.body.children[9].querySelectorAll('tr')[q].querySelectorAll('td')[21].textContent = '';
            }
        }
        for (let k = 0; k < pword.length; k++) {
            document.body.children[9].querySelectorAll('tr')[k].querySelectorAll('td')[21].textContent = pword.charAt(k);
        }
        let matriz = [];
        let vetor = [];
        let letra;
        for (let percorre = 0; percorre < pword.length; percorre++) {
            vetor = [];
            letra = pword[percorre];
            for (let m = 0; m < wordslist.length; m++) {
                if (wordslist[m].indexOf(letra) !== -1) {
                    vetor.push(wordslist[m]);
                }
            }
            matriz.push(vetor);
        }
        let u = 0;
        let max = matriz[0].length;
        let vetocupados = [];
        let ocorrencias = [];
        while (u < pword.length) {
            for (let t = 0; t < matriz.length; t++) {
                if (matriz[t].length > max) {
                    max = matriz[t].length;
                }
            }
            min = max;
            let posi = 0;
            for (let v = 0; v < matriz.length; v++) {
                if (matriz[v].length < min && vetocupados.indexOf(v) === -1) {
                    min = matriz[v].length;
                    posi = v;
                }
                if (vetocupados.length === matriz.length - 1 && matriz[v].length === max) {
                    min = matriz[v].length;
                    posi = v;
                }
            }
            vetocupados.push(posi);
            let aparicoes = [];
            let palavraqueserepete;
            for (let f = 0; f < matriz[posi].length; f++) {
                palavraqueserepete = matriz[posi][f];
                let vezesqueaparece = 0;
                for (let d = 0; d < matriz.length; d++) {
                    if (matriz[d].indexOf(palavraqueserepete) !== -1) {
                        vezesqueaparece++;
                    }
                }
                aparicoes.push(vezesqueaparece);
            }

            let omenor = Math.min.apply(null, aparicoes);
            let palavraaretirar = matriz[posi][aparicoes.indexOf(omenor)];
            if (omenor === Infinity && umavez === 0) {
                umavez = 1;
                for (let n = 0; n < 40; n++) {
                    for (let s = 0; s < 41; s++) {
                        document.body.children[9].querySelectorAll('tr')[n].querySelectorAll('td')[s].textContent = '';
                    }
                }
                document.body.children[9].querySelectorAll('tr')[0].querySelectorAll('td')[21].textContent = 'Não foi possível gerar um acróstico :( Experimente carregar a página novamente e tentar outras combinações! ';
            }
            if (umavez === 0) {
                ocorrencias.push(palavraaretirar);
                for (let r = 0; r < matriz.length; r++) {
                    if (matriz[r].indexOf(palavraaretirar) !== -1) {
                        matriz[r] = acrostic.tirar(matriz[r], palavraaretirar);
                    }
                }
                let w = palavraaretirar.indexOf(pword[posi]);
                let y = 0;
                for (let l = w; l > 0; l--) {
                    document.body.children[9].querySelectorAll('tr')[posi].querySelectorAll('td')[21 - l].textContent = palavraaretirar[y];
                    y++;
                }
                for (let k = w - y; k < (palavraaretirar.length); k++) {
                    document.body.children[9].querySelectorAll('tr')[posi].querySelectorAll('td')[21 + k].textContent = palavraaretirar[y];
                    y++;
                }
            }
            u++;
        }
    }
};
const buttonGenerate = document.querySelectorAll('button')[2];
buttonGenerate.addEventListener('click', acrostic.generate);

const buttonAdd = document.querySelector('button:nth-of-type(1)');
buttonAdd.addEventListener('click', acrostic.add);

const buttonRemove = document.body.children[4];
buttonRemove.addEventListener('click', acrostic.remove);
